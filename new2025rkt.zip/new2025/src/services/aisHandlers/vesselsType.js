"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VESSEL_TYPE = void 0;
exports.VESSEL_TYPE = {
    0: { code: 0, description: "Not available (default)" },
    20: { code: 20, description: "Wing in ground (WIG), all ships of this type" },
    21: { code: 21, description: "Wing in ground (WIG), Hazardous category A" },
    30: { code: 30, description: "Fishing" },
    31: { code: 31, description: "Towing" },
    32: { code: 32, description: "Towing: length exceeds 200m or breadth exceeds 25m" },
    33: { code: 33, description: "Dredging or underwater ops" },
    34: { code: 34, description: "Diving ops" },
    35: { code: 35, description: "Military ops" },
    36: { code: 36, description: "Sailing" },
    37: { code: 37, description: "Pleasure Craft" },
    40: { code: 40, description: "High speed craft (HSC), all ships of this type" },
    50: { code: 50, description: "Pilot Vessel" },
    51: { code: 51, description: "Search and Rescue vessel" },
    52: { code: 52, description: "Tug" },
    53: { code: 53, description: "Port Tender" },
    54: { code: 54, description: "Anti-pollution equipment" },
    55: { code: 55, description: "Law Enforcement" },
    56: { code: 56, description: "Spare - Local Vessel" },
    58: { code: 58, description: "Medical Transport" },
    60: { code: 60, description: "Passenger, all ships of this type" },
    70: { code: 70, description: "Cargo, all ships of this type" },
    80: { code: 80, description: "Tanker, all ships of this type" },
    90: { code: 90, description: "Other Type, all ships of this type" },
};
