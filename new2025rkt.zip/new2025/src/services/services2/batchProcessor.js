"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addToQueue = addToQueue;
exports.processQueue = processQueue;
exports.startBatchProcessor = startBatchProcessor;
const aisDecoder_1 = require("./aisDecoder");
const ais_stream_decoder_1 = __importDefault(require("ais-stream-decoder"));
const parse = new ais_stream_decoder_1.default();
const queue = [];
const MAX_BATCH_SIZE = 200; // Ukuran batch maksimal
const MAX_QUEUE_SIZE = 200; // Batas maksimal antrean
let processing = false; // Flag untuk mengecek apakah sedang memproses data
function addToQueue(message) {
    // Cek jika antrean sudah mencapai batas maksimal
    if (queue.length >= MAX_QUEUE_SIZE) {
        // console.log(`Queue is full, skipping new message. Queue size: ${queue.length}`);
        return; // Jika sudah penuh, hentikan penerimaan pesan baru
    }
    // Masukkan pesan ke dalam antrean
    queue.push(message);
    // console.log(`Message added to queue. Queue size: ${queue.length}`);
}
async function processQueue() {
    if (processing) {
        // console.log("Already processing, skipping this batch.");
        return; // Jika sedang memproses, hentikan eksekusi
    }
    processing = true;
    // console.log("Starting to process queue...");
    // Proses batch jika antrean memiliki data
    while (queue.length > 0) {
        const batch = queue.splice(0, MAX_BATCH_SIZE); // Ambil batch dari antrean
        // console.log(`Processing batch of size: ${batch.length}`);
        try {
            await Promise.all(batch.map((nmea) => (0, aisDecoder_1.decodeAisMessage)(nmea.trim())));
            // console.log("Batch processed successfully.");
            // After processing, wait for 5 seconds to rest before the next batch
            // console.log("Resting for 5 seconds before processing the next batch...");
        }
        catch (err) {
            console.error("Error processing batch:", err);
        }
    }
    processing = false; // Reset flag setelah pemrosesan selesai
    console.log("Queue processing complete.");
}
function startBatchProcessor(interval) {
    setInterval(() => {
        if (queue.length > 0 && !processing) {
            processQueue(); // Mulai memproses antrean jika ada data dan tidak sedang memproses
        }
    }, interval); // Interval untuk memproses antrean
}
