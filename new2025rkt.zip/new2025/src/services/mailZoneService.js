"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailZoneService = void 0;
// src/services/mailZoneService.ts
const mailZone_1 = __importDefault(require("../models/mailZone"));
class MailZoneService {
    // Function to check for duplicate and create a new SBNP Zone
    async createSbnZone(data) {
        const { sbnpName, sbnpType, selectedApiKey, mmsi, baseStationMmsi, longitude, latitude } = data;
        // Check if the zone already exists based on sbnpName, baseStationMmsi, or selectedApiKey
        const existingZone = await mailZone_1.default.findOne({
            $or: [
                { sbnpName },
                { mmsi },
                { selectedApiKey },
            ]
        });
        if (existingZone) {
            throw new Error('SBNP Zone with the same name, MMSI, or API Key already exists.');
        }
        // Create a new SBNP Zone
        const newZone = new mailZone_1.default({
            sbnpName,
            sbnpType,
            selectedApiKey,
            mmsi,
            baseStationMmsi,
            longitude,
            latitude,
        });
        // Save the new zone to the database
        await newZone.save();
        return newZone; // Return the created zone object
    }
    async getAllMailZones() {
        try {
            // Example database call to fetch all mail zones
            const mailZones = await mailZone_1.default.find(); // For MongoDB, or your DB equivalent
            return mailZones;
        }
        catch (error) {
            throw new Error('Error fetching mail zones');
        }
    }
    async getMailZoneById(id) {
        return mailZone_1.default.findById(id);
    }
    async deleteMailZone(id) {
        return mailZone_1.default.findByIdAndDelete(id);
    }
}
exports.MailZoneService = MailZoneService;
