"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.markRawDataAsProcessed = exports.getUnprocessedRawData = exports.saveRawData = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const RawDataSchema = new mongoose_1.default.Schema({
    rawMessage: { type: String, required: true },
    status: { type: Boolean, default: false },
    timestamp: { type: Date, default: Date.now },
});
const RawData = mongoose_1.default.model('RawData', RawDataSchema);
// Fungsi untuk menyimpan raw data AIS
const saveRawData = (message) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const rawData = new RawData({
            rawMessage: message,
            status: false,
        });
        yield rawData.save();
        console.log('Raw data saved to MongoDB');
    }
    catch (error) {
        console.error('Error saving raw data:', error);
    }
});
exports.saveRawData = saveRawData;
// Fungsi untuk mendapatkan raw data yang belum didecode
const getUnprocessedRawData = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (limit = 100) {
    try {
        return yield RawData.find({ status: false }).limit(limit);
    }
    catch (error) {
        console.error('Error fetching unprocessed raw data:', error);
        return [];
    }
});
exports.getUnprocessedRawData = getUnprocessedRawData;
// Fungsi untuk menandai raw data sudah didecode
const markRawDataAsProcessed = (id) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield RawData.updateOne({ _id: id }, { status: true });
        console.log(`Raw data with ID: ${id} marked as processed`);
    }
    catch (error) {
        console.error('Error marking raw data as processed:', error);
    }
});
exports.markRawDataAsProcessed = markRawDataAsProcessed;
exports.default = RawData;
