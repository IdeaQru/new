"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NAV_STATUS = void 0;
exports.NAV_STATUS = {
    0: { code: 0, description: "Under way using engine" },
    1: { code: 1, description: "At anchor" },
    2: { code: 2, description: "Not under command" },
    3: { code: 3, description: "Restricted manoeuverability" },
    4: { code: 4, description: "Constrained by her draught" },
    5: { code: 5, description: "Moored" },
    6: { code: 6, description: "Aground" },
    7: { code: 7, description: "Engaged in Fishing" },
    8: { code: 8, description: "Under way sailing" },
    9: { code: 9, description: "Reserved for future amendment of Navigational Status for HSC" },
    10: { code: 10, description: "Reserved for future amendment of Navigational Status for WIG" },
    11: { code: 11, description: "Reserved for future use" },
    12: { code: 12, description: "Reserved for future use" },
    13: { code: 13, description: "Reserved for future use" },
    14: { code: 14, description: "AIS-SART is active" },
    15: { code: 15, description: "Not defined (default)" },
};
