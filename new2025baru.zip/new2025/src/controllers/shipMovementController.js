"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLatestMovement = exports.getShipMovements = void 0;
const shipMovement_1 = require("../models/shipMovement"); // Assuming this is the model for ship movements
const shapeZone_1 = __importDefault(require("../models/shapeZone")); // Shape model for zones
const combinedAisData_1 = __importDefault(require("../models/combinedAisData")); // Assuming CombinedAisData holds ship data
const turf = __importStar(require("@turf/turf"));
// This function will be called periodically to check ship positions and detect zone crossings
async function checkShipMovements() {
    try {
        // Step 1: Fetch all ships
        const ships = await combinedAisData_1.default.find();
        // Step 2: Fetch all zones (polygons and circles)
        const zones = await shapeZone_1.default.find();
        // Step 3: For each ship, check if it's inside any zone
        for (const ship of ships) {
            const shipMMSI = ship.MMSI;
            const shipCoords = ship.coordinates.coordinates; // Assuming coordinates are [longitude, latitude]
            // Step 4: Check each zone
            for (const zone of zones) {
                const zoneId = zone._id.toString();
                const zoneType = zone.type;
                const zoneCoords = zone.coordinates;
                // Step 5: Check if the ship is inside the zone
                let action = '';
                if (zoneType === 'polygon') {
                    const isInside = isPointInPolygon([shipCoords[0], shipCoords[1]], zoneCoords[0]); // Using turf.js
                    if (isInside)
                        action = 'enter';
                }
                else if (zoneType === 'circle') {
                    const isInside = isPointInCircle([shipCoords[0], shipCoords[1]], zoneCoords);
                    if (isInside)
                        action = 'enter';
                }
                const lastMovement = await shipMovement_1.ShipMovement.findOne({
                    shipId: ship.MMSI,
                    zoneId,
                }).sort({ timestamp: -1 }); // Sorting by the latest timestamp
                if ((lastMovement === null || lastMovement === void 0 ? void 0 : lastMovement.shipId) === ship.MMSI) {
                    // Check if the ship was inside the zone during the last recorded movement
                    let isStillInside = false;
                    if (zoneType === 'polygon') {
                        isStillInside = isPointInPolygon([lastMovement.longitude, lastMovement.latitude], zoneCoords[0]);
                    }
                    else if (zoneType === 'circle') {
                        isStillInside = isPointInCircle([lastMovement.longitude, lastMovement.latitude], zoneCoords);
                    }
                    // console.log(lastMovement.shipId);
                    // console.log("sTILL INSIDE",isStillInside);
                    if (!isStillInside) {
                        action = 'exit';
                    }
                    // If the ship is not inside anymore, mark as 'exit'
                }
                // Step 7: Check for "enter" and "exit" actions separately
                if (action === 'enter') {
                    await checkMovementEnter(ship, zone, shipCoords);
                }
                else if (action === 'exit') {
                    await checkMovementExit(ship, zone, shipCoords);
                }
            }
        }
    }
    catch (error) {
        console.error('Error checking ship movements:', error);
    }
}
// Function to handle the "enter" action
async function checkMovementEnter(ship, zone, shipCoords) {
    var _a;
    // Fetch the last movement of the ship
    const lastMovement = await shipMovement_1.ShipMovement.findOne({
        shipId: ship.MMSI,
        zoneId: zone._id.toString(),
    }).sort({ timestamp: -1 }); // Sorting by the latest timestamp
    // If there's no previous entry or the last action was 'exit', save the 'enter' action
    if (!lastMovement || lastMovement.action === 'exit') {
        const newMovement = new shipMovement_1.ShipMovement({
            shipId: ship.MMSI,
            shipName: ship.ShipName || 'Unknown Ship',
            zoneId: zone._id.toString(),
            ShipType: ship.ShipType,
            zoneName: ((_a = zone.properties) === null || _a === void 0 ? void 0 : _a.name) || 'Unknown Zone',
            zoneType: zone.type,
            action: 'enter',
            latitude: shipCoords[1],
            longitude: shipCoords[0],
            timestamp: new Date(),
            sog: ship.SpeedOverGround,
            cog: ship.CourseOverGround,
            heading: ship.Heading,
            destination: ship.Destination || 'Unknown',
        });
        await newMovement.save();
        console.log(`Ship ${ship.MMSI} entered zone ${zone._id.toString()}`);
    }
    else {
        console.log(`Ship ${ship.MMSI} already entered zone ${zone._id.toString()} today`);
    }
}
// Function to handle the "exit" action
async function checkMovementExit(ship, zone, shipCoords) {
    var _a;
    // Fetch the last movement of the ship
    const lastMovement = await shipMovement_1.ShipMovement.findOne({
        shipId: ship.MMSI,
        zoneId: zone._id.toString(),
    }).sort({ timestamp: -1 }); // Sorting by the latest timestamp
    // If the ship is inside and the last recorded action was 'enter', mark as 'exit'
    if (lastMovement && lastMovement.action === 'enter') {
        const exitMovement = new shipMovement_1.ShipMovement({
            shipId: ship.MMSI,
            shipName: ship.ShipName || 'Unknown Ship',
            zoneId: zone._id.toString(),
            ShipType: ship.ShipType,
            zoneName: ((_a = zone.properties) === null || _a === void 0 ? void 0 : _a.name) || 'Unknown Zone',
            zoneType: zone.type,
            action: 'exit',
            latitude: shipCoords[1],
            longitude: shipCoords[0],
            timestamp: new Date(),
            sog: ship.SpeedOverGround,
            cog: ship.CourseOverGround,
            heading: ship.Heading,
            destination: ship.Destination || 'Unknown',
        });
        await exitMovement.save();
        console.log(`Ship ${ship.MMSI} exited zone ${zone._id.toString()}`);
    }
}
// Helper function to check if a point is inside a polygon (using Turf.js)
function isPointInPolygon(point, polygon) {
    // Ensure that the first and last point of the polygon are the same (i.e., close the polygon)
    if (polygon[0].lat !== polygon[polygon.length - 1].lat || polygon[0].lng !== polygon[polygon.length - 1].lng) {
        polygon.push(polygon[0]); // Close the polygon by making the first and last points identical
    }
    // Convert to proper format for Turf
    const turfPolygon = turf.polygon([polygon.map(coord => [coord.lng, coord.lat])]);
    const turfPoint = turf.point([point[0], point[1]]); // Ship's coordinates as a point
    return turf.booleanPointInPolygon(turfPoint, turfPolygon); // Return true if the point is inside the polygon
}
// Function to check if the ship is inside a circle zone
function isPointInCircle(point, circle) {
    const distance = getDistance(point, [circle.lng, circle.lat]); // Calculate distance between point and center of circle
    return distance <= circle.radius; // Check if the ship is inside the circle based on the radius
}
// Function to calculate the distance between two points (lat/lng)
function getDistance(point1, point2) {
    const R = 6371; // Radius of Earth in km
    const dLat = deg2rad(point2[1] - point1[1]);
    const dLon = deg2rad(point2[0] - point1[0]);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(point1[1])) * Math.cos(deg2rad(point2[1])) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c * 1000; // Distance in meters
}
// Convert degrees to radians
function deg2rad(deg) {
    return deg * (Math.PI / 180);
}
// Step 6: Run this function periodically (for example, using setInterval)
// API to fetch ship movements
const getShipMovements = async (req, res) => {
    try {
        const { zoneId, action, startDate, endDate } = req.query;
        // Build the query object
        let query = {};
        if (zoneId) {
            query.zoneId = zoneId; // Filter by zoneId if provided
        }
        if (action) {
            query.action = action; // Filter by action (enter/exit) if provided
        }
        if (startDate && endDate) {
            // Filter by timestamp if startDate and endDate are provided
            query.timestamp = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        // Fetch ship movements based on the query object
        const shipMovements = await shipMovement_1.ShipMovement.find(query)
            .sort({ timestamp: -1 }) // Sort by timestamp, newest first
            .exec();
        res.status(200).json({
            count: shipMovements.length,
            shipMovements,
        });
    }
    catch (error) {
        console.error("Error retrieving ship movements:", error);
        res.status(500).json({ message: 'Error retrieving ship movements', error });
    }
};
exports.getShipMovements = getShipMovements;
// API to fetch the latest ship movement
const getLatestMovement = async (req, res) => {
    try {
        // Fetch the latest movement based on timestamp
        const latestMovement = await shipMovement_1.ShipMovement.findOne()
            .sort({ timestamp: -1 }) // Sort by latest timestamp
            .select('shipId shipName timestamp zoneName action') // Only return necessary fields
            .exec();
        if (!latestMovement) {
            return res.status(404).json({ message: 'No ship movements found' });
        }
        res.json({
            shipId: latestMovement.shipId,
            shipName: latestMovement.shipName,
            timestamp: latestMovement.timestamp,
            zoneName: latestMovement.zoneName,
            action: latestMovement.action
        });
    }
    catch (error) {
        console.error('Error fetching latest ship movement:', error);
        res.status(500).json({ message: 'Internal server error', error });
    }
};
exports.getLatestMovement = getLatestMovement;
async function deleteDuplicateShipMovements() {
    try {
        // Mencari data dengan kondisi yang sama pada zone yang sama dan action yang sama
        const duplicateShipMovements = await shipMovement_1.ShipMovement.aggregate([
            {
                $group: {
                    _id: {
                        zoneId: "$zoneId",
                        shipId: "$shipId",
                        action: "$action",
                        timestamp: "$timestamp"
                    },
                    count: { $sum: 1 }, // Menghitung jumlah data dengan kombinasi yang sama
                    ids: { $push: "$_id" }, // Menyimpan ID dari dokumen-dokumen yang memiliki kombinasi yang sama
                },
            },
            {
                $match: { count: { $gt: 1 } }, // Hanya ambil data yang memiliki lebih dari satu entry
            },
        ]);
        // Looping untuk menghapus duplikat berdasarkan hasil yang ditemukan
        for (const duplicate of duplicateShipMovements) {
            const [firstId, ...restIds] = duplicate.ids;
            // Menghapus semua dokumen duplikat, kecuali yang pertama (firstId)
            await shipMovement_1.ShipMovement.deleteMany({ _id: { $in: restIds } });
        }
        console.log("Duplikat data telah berhasil dihapus.");
    }
    catch (error) {
        console.error("Terjadi kesalahan saat menghapus data duplikat:", error);
    }
}
// Panggil fungsi untuk menghapus duplikat
setInterval(deleteDuplicateShipMovements, 10000); // Execute every 10 seconds for real-time updates
setInterval(checkShipMovements, 2000); // Execute every 10 seconds for real-time updates
