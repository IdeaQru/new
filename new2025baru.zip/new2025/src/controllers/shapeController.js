"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getShipsByShapeId = exports.countShipsInPolygon = exports.editShape = exports.getMmsiAndCoordinates = exports.deleteShape = exports.getCircleShapes = exports.getPolygonShapes = exports.getShapes = exports.saveShape = void 0;
const shapeZone_1 = __importDefault(require("../models/shapeZone"));
const combinedAisData_1 = __importDefault(require("../models/combinedAisData"));
const saveShape = async (req, res) => {
    try {
        const newShape = new shapeZone_1.default(req.body);
        await newShape.save();
        res.status(201).send(newShape);
    }
    catch (error) {
        res.status(400).send(error);
    }
};
exports.saveShape = saveShape;
const getShapes = async (req, res) => {
    try {
        const shapes = await shapeZone_1.default.find({});
        res.status(200).send(shapes);
    }
    catch (error) {
        res.status(500).send(error);
    }
};
exports.getShapes = getShapes;
const getPolygonShapes = async (req, res) => {
    try {
        const polygons = await shapeZone_1.default.find({ type: 'polygon' });
        res.status(200).send(polygons);
    }
    catch (error) {
        res.status(500).send(error);
    }
};
exports.getPolygonShapes = getPolygonShapes;
const getCircleShapes = async (req, res) => {
    try {
        const circles = await shapeZone_1.default.find({ type: 'circle' });
        res.status(200).send(circles);
    }
    catch (error) {
        res.status(500).send(error);
    }
};
exports.getCircleShapes = getCircleShapes;
const deleteShape = async (req, res) => {
    try {
        const shapeId = req.params.id; // Mengambil ID dari parameter URL
        const deletedShape = await shapeZone_1.default.findByIdAndDelete(shapeId);
        if (!deletedShape) {
            return res.status(404).send({ message: "Shape not found" });
        }
        res.send({ message: "Shape deleted successfully" });
    }
    catch (error) {
        res.status(500).send({ message: "Error deleting shape", error: error });
    }
};
exports.deleteShape = deleteShape;
const getMmsiAndCoordinates = async (req, res) => {
    try {
        const shapes = await shapeZone_1.default.find({}, 'properties.mmsi coordinates');
        res.json(shapes);
    }
    catch (err) {
        res.status(500).json({ message: 'Error retrieving data', error: err });
    }
};
exports.getMmsiAndCoordinates = getMmsiAndCoordinates;
const editShape = async (req, res) => {
    try {
        const shapeId = req.params.id; // Mengambil ID dari parameter URL
        const updatedData = req.body; // Mengambil data baru dari body request
        // Mencari dan memperbarui shape berdasarkan ID
        const updatedShape = await shapeZone_1.default.findByIdAndUpdate(shapeId, updatedData, { new: true, runValidators: true } // Mengembalikan data yang diperbarui dan memvalidasi data
        );
        if (!updatedShape) {
            return res.status(404).send({ message: "Shape not found" });
        }
        res.status(200).send(updatedShape);
    }
    catch (error) {
        res.status(400).send({ message: "Error updating shape", error });
    }
};
exports.editShape = editShape;
const countShipsInPolygon = async (req, res) => {
    try {
        const { polygon } = req.body; // Polygon adalah array dari koordinat lat, lng
        // Pastikan format polygon sesuai dengan koordinat lat, lng
        const polygonCoordinates = polygon.map((coord) => [coord.lng, coord.lat]);
        // Query untuk mencari kapal yang berada di dalam poligon
        const shipsInPolygon = await combinedAisData_1.default.find({
            coordinates: { $geoWithin: { $polygon: polygonCoordinates } }
        });
        res.status(200).json({
            count: shipsInPolygon.length,
            ships: shipsInPolygon
        });
    }
    catch (error) {
        res.status(500).json({ message: 'Error counting ships in polygon', error });
    }
};
exports.countShipsInPolygon = countShipsInPolygon;
// Fungsi untuk mendapatkan kapal berdasarkan ID Shape (polygon atau circle)
const getShipsByShapeId = async (req, res) => {
    try {
        const shapeId = req.params.id; // Mengambil ID Shape dari parameter URL
        // Cari Shape berdasarkan ID
        const shape = await shapeZone_1.default.findById(shapeId);
        if (!shape) {
            return res.status(404).json({ message: 'Shape not found' });
        }
        let ships = [];
        // Cek tipe Shape, apakah polygon atau circle
        if (shape.type === 'polygon') {
            // Pastikan koordinat berbentuk [longitude, latitude] untuk MongoDB
            const polygonCoordinates = shape.coordinates[0].map((coord) => [coord.lng, coord.lat]);
            // Query kapal yang berada dalam poligon menggunakan $geoWithin
            ships = await combinedAisData_1.default.find({
                coordinates: { $geoWithin: { $polygon: polygonCoordinates } }
            }, {
                // Hanya memilih field yang dibutuhkan
                MMSI: 1,
                coordinates: 1,
                ShipType: 1,
                SpeedOverGround: 1,
                CourseOverGround: 1
            });
        }
        else if (shape.type === 'circle') {
            const { lat, lng, radius } = shape.coordinates;
            // Query kapal yang berada dalam radius dari titik pusat lingkaran menggunakan $near
            ships = await combinedAisData_1.default.find({
                coordinates: {
                    $near: {
                        $geometry: {
                            type: 'Point',
                            coordinates: [lng, lat] // Pastikan urutannya [longitude, latitude]
                        },
                        $maxDistance: radius // Radius dalam meter
                    }
                }
            }, {
                // Hanya memilih field yang dibutuhkan
                MMSI: 1,
                coordinates: 1,
                ShipType: 1,
                SpeedOverGround: 1,
                CourseOverGround: 1
            });
        }
        // Mengembalikan jumlah kapal yang ditemukan di zona tersebut
        res.status(200).json({
            count: ships.length,
            ships: ships
        });
    }
    catch (error) {
        res.status(500).json({ message: 'Error retrieving ships', error });
    }
};
exports.getShipsByShapeId = getShipsByShapeId;
