"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShipMovement = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const ShipMovementSchema = new mongoose_1.Schema({
    shipId: { type: Number, required: true }, // MMSI of the ship
    shipName: { type: String, default: "Unknown Ship Name" }, // Ship's name
    zoneId: { type: String, required: true }, // ID of the zone (from Shape data)
    zoneType: { type: String, required: true }, // Type of the zone (polygon/circle)
    zoneName: { type: String, required: true }, // Name of the zone (from Shape data)
    action: { type: String, enum: ["enter", "exit"], required: true }, // Action (enter/exit)
    latitude: { type: Number, required: true }, // Ship's latitude when entering/exiting the zone
    longitude: { type: Number, required: true }, // Ship's longitude when entering/exiting the zone
    timestamp: { type: Date, required: true }, // Timestamp of the action
    sog: { type: Number, default: null }, // Speed Over Ground
    cog: { type: Number, default: null }, // Course Over Ground
    ShipType: { type: Number },
    heading: { type: Number, default: null }, // Heading of the ship
    destination: { type: String, default: null }, // Ship's destination
});
exports.ShipMovement = mongoose_1.default.model("ShipMovement", ShipMovementSchema);
