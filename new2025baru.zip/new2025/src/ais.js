"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ais_decoder_1 = __importDefault(require("ais-decoder"));
const session = {};
const part1 = "!AIVDM,2,1,9,A,59NSON`2@08dCE4KP00Dh5840000000000000016B0F>94a90DDUH42hh000,0*0D";
const part2 = "!AIVDM,2,2,9,A,00000000000,2*2D";
// Invalid AIS Message: !AIVDM,2,1,9,A,59NSON`2@08dCE4KP00Dh5840000000000000016B0F>94a90DDUH42hh000,0*0D
// Invalid AIS Message: !AIVDM,2,2,9,A,00000000000,2*2D
// Process part 1
let aisDecoder = new ais_decoder_1.default.AisDecode(part1, session);
console.log("Session 1 ", session);
// Process part 2 (now continuing with the same session)
aisDecoder = new ais_decoder_1.default.AisDecode(part2, session);
console.log("Session 2 ", session);
console.log(aisDecoder);
// You can then use the decoded messages for further processing...
