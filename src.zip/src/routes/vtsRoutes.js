"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const aisMessage_1 = require("../models/aisMessage");
const router = (0, express_1.Router)();
router.get('/vts', async (req, res) => {
    try {
        const now = new Date();
        // Ambil semua data dynamic terbaru untuk setiap MMSI
        const dynamicData = await aisMessage_1.DynamicModel.aggregate([
            { $match: { 'data.aistype': 4, expirationTime: { $gt: now } } },
            { $sort: { expirationTime: -1 } },
            { $group: { _id: "$data.mmsi", latestDynamic: { $first: "$$ROOT" } } }
        ]);
        // Iterasi setiap dynamic data untuk mencocokkan dengan static data
        const mergedData = await Promise.all(dynamicData.map(async (dynamic) => {
            var _a;
            // Ambil data static terbaru yang cocok dengan mmsi
            const staticData = await aisMessage_1.StaticModel.findOne({
                'data.mmsi': dynamic._id,
            })
                .sort({ updatedAt: -1 })
                .lean();
            // Tentukan waktu data diterima
            const receivedTime = dynamic.latestDynamic.createdAt || dynamic.latestDynamic.updatedAt;
            // Gabungkan data dynamic dengan static jika ditemukan
            return {
                mmsi: dynamic._id,
                shipname: ((_a = staticData === null || staticData === void 0 ? void 0 : staticData.data) === null || _a === void 0 ? void 0 : _a.shipname) || 'Unknown', // Ambil shipname dari static jika ada
                dynamicData: dynamic.latestDynamic,
                receivedTime: receivedTime, // Tambahkan waktu data diterima
            };
        }));
        // Kirim hasil yang digabungkan
        res.json({
            success: true,
            data: mergedData,
        });
    }
    catch (err) {
        console.error('Error fetching merged AIS data:', err);
        res.status(500).json({
            success: false,
            message: 'Error fetching merged AIS data',
        });
    }
});
exports.default = router;
