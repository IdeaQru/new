"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addToQueue = addToQueue;
exports.processQueue = processQueue;
exports.startBatchProcessor = startBatchProcessor;
const shipMovementController_1 = require("../../controllers/shipMovementController");
const aisDecoder_1 = require("./aisDecoder");
const ais_stream_decoder_1 = __importDefault(require("ais-stream-decoder"));
const parse = new ais_stream_decoder_1.default();
const queue = [];
const MAX_BATCH_SIZE = 200; // Ukuran batch maksimal
const MAX_QUEUE_SIZE = 200; // Batas maksimal antrean
let processing = false; // Flag untuk mengecek apakah sedang memproses data
function addToQueue(message) {
    // Cek jika antrean sudah mencapai batas maksimal
    if (queue.length >= MAX_QUEUE_SIZE) {
        return; // Jika sudah penuh, hentikan penerimaan pesan baru
    }
    // Masukkan pesan ke dalam antrean
    queue.push(message);
}
async function processQueue() {
    if (processing) {
        return; // Jika sedang memproses, hentikan eksekusi
    }
    processing = true;
    while (queue.length > 0) {
        const batch = queue.splice(0, MAX_BATCH_SIZE); // Ambil batch dari antrean
        try {
            // Process batch asynchronously and concurrently
            await Promise.all(batch.map(async (nmea) => {
                try {
                    // Decode AIS message asynchronously
                    await (0, aisDecoder_1.decodeAisMessage)(nmea.trim());
                }
                catch (err) {
                    console.error("Error decoding AIS message:", err);
                }
            }));
            // After processing, you may want to handle duplicates or check ship movements
            // await checkShipMovements();  // This checks if the ship movements are up to date
            await (0, shipMovementController_1.deleteDuplicateShipMovements)(); // This removes duplicates in the database
        }
        catch (err) {
            console.error("Error processing batch:", err);
        }
    }
    processing = false; // Reset flag setelah pemrosesan selesai
    console.log("Queue processing complete.");
}
function startBatchProcessor(interval) {
    setInterval(async () => {
        if (queue.length > 0 && !processing) {
            // Start processing only if there is data and we are not already processing
            await processQueue(); // Mulai memproses antrean
        }
    }, interval); // Interval untuk memproses antrean
}
