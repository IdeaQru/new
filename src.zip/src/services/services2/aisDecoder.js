"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeAisMessage = decodeAisMessage;
const Ideaqru = __importStar(require("ais-decoder"));
const aisMessage_1 = require("../../models/aisMessage");
const getCombinedAISData_1 = require("../../services/aisHandlers/getCombinedAISData");
let messagePairs = []; // Array untuk menyimpan pesan multipart sementara
/**
 * Fungsi untuk mendekode pesan AIS
 */
async function decodeAisMessage(nmea) {
    try {
        const aisDecoder = new Ideaqru.AisDecode(nmea, {});
        if (aisDecoder.valid) {
            const messageType = aisDecoder.aistype;
            const mmsi = Number(aisDecoder.mmsi); // Konversi MMSI ke number
            // Pastikan MMSI valid sebelum menyimpan
            if (!mmsi || isNaN(mmsi)) {
                console.error("Invalid MMSI:", mmsi);
                return;
            }
            const data = { mmsi, raw: nmea, data: aisDecoder };
            if ([5, 24].includes(messageType)) {
                // Pesan statis (Static AIS Messages)
                await aisMessage_1.StaticModel.updateOne({ mmsi }, { $set: data }, { upsert: true });
                // console.log(`Static data saved/updated for MMSI: ${mmsi}`);
            }
            else {
                // Pesan dinamis (Dynamic AIS Messages)
                await aisMessage_1.DynamicModel.create(data);
                // console.log(`Dynamic data saved for MMSI: ${mmsi}`);
            }
            // Gabungkan data AIS untuk disimpan di database utama
            await (0, getCombinedAISData_1.getAndCombineAisData)(mmsi);
        }
        else {
            console.warn("Invalid AIS Message received:", nmea);
            // Simpan pesan multipart sementara
            messagePairs.push(nmea);
            // Jika sudah ada 2 pesan, coba decode sebagai multipart
            if (messagePairs.length >= 2) {
                await processPairMessage(messagePairs[0], messagePairs[1]);
                messagePairs = []; // Reset array setelah diproses
            }
        }
    }
    catch (err) {
        console.error("Error decoding AIS Message:", err);
    }
}
/**
 * Fungsi untuk memproses pasangan pesan multipart AIS
 */
async function processPairMessage(part1, part2) {
    try {
        let session = {}; // Menyimpan sesi decoding untuk pesan multipart
        // Proses bagian pertama
        let aisDecoder = new Ideaqru.AisDecode(part1, session);
        // Proses bagian kedua dengan sesi yang sama
        aisDecoder = new Ideaqru.AisDecode(part2, session);
        // Jika decoding berhasil
        if (aisDecoder.valid) {
            const mmsi = Number(aisDecoder.mmsi);
            // Pastikan MMSI valid sebelum menyimpan
            if (!mmsi || isNaN(mmsi)) {
                console.error("Invalid MMSI in multipart message:", mmsi);
                return;
            }
            const decodedData = {
                mmsi,
                raw: { part1, part2 },
                data: aisDecoder,
            };
            // Simpan ke StaticModel
            await aisMessage_1.StaticModel.updateOne({ mmsi }, { $set: decodedData }, { upsert: true });
            console.log(`Static data saved/updated for multipart MMSI: ${mmsi}`);
            // Gabungkan data AIS ke dalam database utama
            await (0, getCombinedAISData_1.getAndCombineAisData)(mmsi);
        }
        else {
            console.error("Failed to decode the multipart message.");
        }
    }
    catch (err) {
        console.error("Error processing multipart AIS message:", err);
    }
}
