"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAndCombineAisData = void 0;
const moment_1 = __importDefault(require("moment"));
const aisLogData_1 = require("./aisLogData");
const aisMessage_1 = require("../../models/aisMessage"); // Model Static
const aisMessage_2 = require("../../models/aisMessage"); // Model Dynamic
const aisMessage_3 = require("../../models/aisMessage"); // Model Dynamic
const combinedAisData_1 = __importDefault(require("../../models/combinedAisData")); // Model Combined
// Impor data dari file terpisah
const msgType_1 = require("./msgType");
const navStatus_1 = require("./navStatus");
const vesselsType_1 = require("./vesselsType");
const shipMovementController_1 = require("../../controllers/shipMovementController");
const getAndCombineAisData = async (mmsi) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
    try {
        // Ambil data dinamis terbaru berdasarkan timestamp
        const latestDynamicData = await aisMessage_2.DynamicModel.findOne({ mmsi })
            .sort({ createdAt: -1 })
            .limit(1);
        // Ambil data statis terbaru berdasarkan timestamp
        const latestStaticData = await aisMessage_1.StaticModel.findOne({ mmsi })
            .sort({ createdAt: -1 })
            .limit(1);
        const shipIdentity = await aisMessage_3.ShipIdentityModel.findOne({ MMSI: mmsi });
        // console.log(`${mmsi}`,shipIdentity);
        // if (latestDynamicData?.data.aistype === 4 || latestDynamicData?.data.aistype === 21) {
        //skip
        // } else {    // Pastikan data dinamis ada dan memiliki koordinat (longitude, latitude)
        if (latestDynamicData && latestDynamicData.data.lon !== undefined && latestDynamicData.data.lat !== undefined) {
            const now = new Date();
            const formattedTimestamp = (0, moment_1.default)().utc().toISOString();
            let heading = latestDynamicData.data.hdg || 0;
            // jika mmsi nya 525021368 namanya BARITO EQUATOR
            // Gabungkan data dinamis dan statis
            const combinedData = {
                MMSI: latestDynamicData.mmsi,
                coordinates: {
                    type: 'Point',
                    coordinates: [latestDynamicData.data.lon, latestDynamicData.data.lat] // [Longitude, Latitude]
                },
                aidtype: ((_a = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _a === void 0 ? void 0 : _a.aidtype) || latestDynamicData.data.aidtype || 0,
                ShipName: ((_b = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _b === void 0 ? void 0 : _b.shipname) || (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.NAME) || latestDynamicData.data.shipname || "Unknown Ship",
                ShipType: ((_c = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _c === void 0 ? void 0 : _c.shiptype) || ((_d = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _d === void 0 ? void 0 : _d.typeAndCargo) ||
                    ((_e = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _e === void 0 ? void 0 : _e.shipType) ||
                    ((_f = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _f === void 0 ? void 0 : _f.modelType) ||
                    ((_g = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _g === void 0 ? void 0 : _g.vesselType) || vesselsType_1.VESSEL_TYPE_BY_DESCRIPTION[(shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.TYPENAME) || "Unknown Ship"] || 0,
                SpeedOverGround: latestDynamicData.data.sog || undefined,
                CourseOverGround: latestDynamicData.data.cog || undefined,
                Heading: heading || undefined,
                Timestamp: formattedTimestamp,
                NavigationStatus: latestDynamicData.data.navstatus || undefined,
                Length: ((_h = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _h === void 0 ? void 0 : _h.length) || undefined,
                Width: ((_j = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _j === void 0 ? void 0 : _j.width) || undefined,
                CallSign: ((_k = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _k === void 0 ? void 0 : _k.callsign) || (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.CALLSIGN) || undefined,
                Class: latestDynamicData.data.class || (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.CLASS) || undefined,
                Channel: latestDynamicData.data.channel || undefined,
                AisTypeDynamic: latestDynamicData.data.aistype || undefined, // Menyimpan aistype dari data dinamis
                AisTypeStatic: ((_l = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _l === void 0 ? void 0 : _l.aistype) || undefined, // Menyimpan aistype dari data statis
                RawAIS: latestDynamicData.raw || undefined,
                Flag: (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.FLAG) || "Unknown Flag", // Flag dari ship_identity
                FlagName: (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.FLAGNAME) || "Unknown Flag Name",
                IMO_Number: (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.IMO) || "Unknown IMO Number",
                // Draught: shipIdentity?.DRAUGHT || undefined,
                // Menambahkan deskripsi ke parameter terpisah
                navstatDesk: ((_m = navStatus_1.NAV_STATUS[latestDynamicData.data.navstatus]) === null || _m === void 0 ? void 0 : _m.description) || undefined,
                msgDynamicDesk: ((_o = msgType_1.MSG_TYPE[latestDynamicData.data.class]) === null || _o === void 0 ? void 0 : _o.description) || undefined,
                msgStaticDesk: ((_q = msgType_1.MSG_TYPE[(_p = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _p === void 0 ? void 0 : _p.aistype]) === null || _q === void 0 ? void 0 : _q.description) || undefined,
                vesseltypeDesk: ((_s = vesselsType_1.VESSEL_TYPE[(_r = latestStaticData === null || latestStaticData === void 0 ? void 0 : latestStaticData.data) === null || _r === void 0 ? void 0 : _r.shiptype]) === null || _s === void 0 ? void 0 : _s.description) || (shipIdentity === null || shipIdentity === void 0 ? void 0 : shipIdentity.TYPENAME) || undefined,
            };
            // Periksa apakah data sudah ada di CombinedAisData
            const existingData = await combinedAisData_1.default.findOne({ MMSI: combinedData.MMSI });
            const existingTimestamp = existingData && existingData.Timestamp
                ? (0, moment_1.default)(existingData.Timestamp, 'DD-MM-YYYY HH:mm:ss')
                : null;
            const newTimestamp = (0, moment_1.default)(combinedData.Timestamp, 'DD-MM-YYYY HH:mm:ss');
            // Jika data baru lebih baru, perbarui atau simpan
            if (!existingTimestamp || newTimestamp.isAfter(existingTimestamp)) {
                await combinedAisData_1.default.updateOne({ MMSI: combinedData.MMSI }, combinedData, { upsert: true });
                await (0, aisLogData_1.saveAisLog)(combinedData.MMSI, combinedData.ShipName, combinedData);
                await (0, shipMovementController_1.checkShipMovements)(combinedData);
                console.log(`Updated AIS data for MMSI: ${combinedData.MMSI} with timestamp: ${combinedData.Timestamp}`);
            }
            else {
                console.log(`Ignored outdated AIS data for MMSI: ${combinedData.MMSI} with timestamp: ${combinedData.Timestamp}`);
            }
        }
        else {
            console.log(`Dynamic data is incomplete (missing longitude or latitude) for MMSI: ${mmsi}`);
        }
        // }
    }
    catch (error) {
        console.error(`Error in getAndCombineAisData for MMSI: ${mmsi}`, error);
    }
};
exports.getAndCombineAisData = getAndCombineAisData;
