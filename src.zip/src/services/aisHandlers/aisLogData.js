"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveAisLog = void 0;
const aisLog_1 = __importDefault(require("../../models/aisLog"));
const moment_1 = __importDefault(require("moment"));
const combinedAisData_1 = __importDefault(require("../../models/combinedAisData")); // Model Combined
/**
 * Fungsi untuk menghitung jarak antara dua titik (menggunakan rumus Haversine)
 * @param lat1 - Latitude titik pertama
 * @param lon1 - Longitude titik pertama
 * @param lat2 - Latitude titik kedua
 * @param lon2 - Longitude titik kedua
 * @returns Jarak dalam meter
 */
function haversine(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Radius of Earth in meters
    const φ1 = lat1 * Math.PI / 180; // Latitude in radians
    const φ2 = lat2 * Math.PI / 180; // Latitude in radians
    const Δφ = (lat2 - lat1) * Math.PI / 180; // Difference in latitude
    const Δλ = (lon2 - lon1) * Math.PI / 180; // Difference in longitude
    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in meters
    return distance;
}
/**
 * Fungsi untuk menyimpan log data AIS ke dalam collection AisLog
 * @param mmsi - Nomor identifikasi kapal (MMSI)
 * @param name - Nama kapal
 * @param combinedData - Data gabungan yang berisi informasi dinamis dan statis dari kapal
 */
const saveAisLog = async (mmsi, name, combinedData) => {
    try {
        const logTime = (0, moment_1.default)(Date.now()).format('DD-MM-YYYY HH:mm:ss');
        // Ambil data yang penting dari combinedData untuk details log
        const logDetails = {
            MMSI: combinedData.MMSI,
            ShipName: combinedData.ShipName || "Unknown Ship",
            ShipType: combinedData.vesseltypeDesk || "Unspecified Type",
            sog: combinedData.SpeedOverGround,
            cog: combinedData.CourseOverGround,
            lon: combinedData.coordinates.coordinates[0],
            lat: combinedData.coordinates.coordinates[1],
            heading: combinedData.Heading,
            destination: combinedData.Destination || "-",
            timestamp: combinedData.Timestamp,
            navigationStatus: combinedData.navstatDesk,
        };
        // Ambil semua kapal selain kapal yang bersangkutan (untuk menghitung nearest vessels)
        const ships = await combinedAisData_1.default.find({ MMSI: { $ne: combinedData.MMSI } }); // Exclude current ship
        const nearestVessels = ships.filter((ship) => {
            const distance = haversine(combinedData.coordinates.coordinates[1], // Latitude of current ship
            combinedData.coordinates.coordinates[0], // Longitude of current ship
            ship.coordinates.coordinates[1], // Latitude of other ship
            ship.coordinates.coordinates[0] // Longitude of other ship
            );
            return distance < 926; // Only include vessels within 926 meters
        });
        // Jika tidak ada kapal terdekat, pastikan nearestVessels adalah array kosong
        const nearestVesselData = nearestVessels.length > 0 ? nearestVessels.map((vessel) => ({
            MMSI: vessel.MMSI,
            ShipName: vessel.ShipName || "Unknown Ship", // Berikan nilai default jika ShipName undefined
            Distance: haversine(combinedData.coordinates.coordinates[1], combinedData.coordinates.coordinates[0], vessel.coordinates.coordinates[1], vessel.coordinates.coordinates[0]),
            RelativeBearing: 0, // If needed, calculate relative bearing
            coordinates: vessel.coordinates
        })) : [];
        // Cek waktu terakhir data yang ada dalam database
        const lastRecord = await aisLog_1.default.findOne({ mmsi }).sort({ logTime: -1 }).exec(); // Ambil log terakhir berdasarkan MMSI
        if (lastRecord) {
            // Cek apakah selisih waktunya lebih dari 8 jam
            const lastSavedDate = (0, moment_1.default)(lastRecord.logTime, 'DD-MM-YYYY HH:mm:ss');
            const currentDate = (0, moment_1.default)(logTime, 'DD-MM-YYYY HH:mm:ss');
            const timeDifference = currentDate.diff(lastSavedDate, 'hours'); // Selisih dalam jam
            if (timeDifference < 8) {
                // Jika waktu kurang dari 8 jam, jangan simpan atau update data
                console.log('Data is too recent to be saved. Must be at least 8 hours apart.');
                return;
            }
        }
        // Data header yang akan disimpan atau diperbarui
        const headerData = {
            mmsi,
            name,
            logTime,
            NearestVessels: nearestVesselData,
        };
        // Simpan atau update log di AisLog collection
        await aisLog_1.default.findOneAndUpdate({ mmsi }, // Cari berdasarkan MMSI
        {
            $set: headerData, // Set data header terbaru
            $push: { details: logDetails }, // Tambahkan data log lainnya ke dalam array details
        }, { upsert: true, new: true } // Buat entri baru jika tidak ada MMSI yang cocok (upsert)
        );
        console.log('AIS Log successfully saved to the database');
    }
    catch (error) {
        console.error('Error saving AIS Log:', error);
    }
};
exports.saveAisLog = saveAisLog;
