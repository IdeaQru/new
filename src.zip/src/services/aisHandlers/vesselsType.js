"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VESSEL_TYPE_BY_DESCRIPTION = exports.VESSEL_TYPE = void 0;
exports.VESSEL_TYPE = {
    0: { code: 0, description: "Not available (default)" },
    20: { code: 20, description: "Wing in ground (WIG), all ships of this type" },
    21: { code: 21, description: "Wing in ground (WIG), Hazardous category A" },
    30: { code: 30, description: "Fishing" },
    31: { code: 31, description: "Towing" },
    32: { code: 32, description: "Towing: length exceeds 200m or breadth exceeds 25m" },
    33: { code: 33, description: "Dredging or underwater ops" },
    34: { code: 34, description: "Diving ops" },
    35: { code: 35, description: "Military ops" },
    36: { code: 36, description: "Sailing" },
    37: { code: 37, description: "Pleasure Craft" },
    40: { code: 40, description: "High speed craft (HSC), all ships of this type" },
    50: { code: 50, description: "Pilot Vessel" },
    51: { code: 51, description: "Search and Rescue vessel" },
    52: { code: 52, description: "Tug" },
    53: { code: 53, description: "Port Tender" },
    54: { code: 54, description: "Anti-pollution equipment" },
    55: { code: 55, description: "Law Enforcement" },
    56: { code: 56, description: "Spare - Local Vessel" },
    58: { code: 58, description: "Medical Transport" },
    60: { code: 60, description: "Passenger, all ships of this type" },
    70: { code: 70, description: "Cargo, all ships of this type" },
    80: { code: 80, description: "Tanker, all ships of this type" },
    90: { code: 90, description: "Other Type, all ships of this type" },
};
exports.VESSEL_TYPE_BY_DESCRIPTION = {
    "Not available (default)": 0,
    "Wing in ground (WIG), all ships of this type": 20,
    "Wing in ground (WIG), Hazardous category A": 21,
    "Fishing": 30,
    "Towing": 31,
    "Towing: length exceeds 200m or breadth exceeds 25m": 32,
    "Dredging or underwater ops": 33,
    "Diving ops": 34,
    "Military ops": 35,
    "Sailing": 36,
    "Pleasure Craft": 37,
    "High speed craft (HSC), all ships of this type": 40,
    "Pilot Vessel": 50,
    "Search and Rescue vessel": 51,
    "Tug": 52,
    "Hopper Dredger": 52,
    "Port Tender": 53,
    "Anti-pollution equipment": 54,
    "Law Enforcement": 55,
    "Spare - Local Vessel": 56,
    "Medical Transport": 58,
    "Passenger, all ships of this type": 60,
    "Cargo, all ships of this type": 70,
    "Tanker, all ships of this type": 80,
    "Other Type, all ships of this type": 90,
    "Passenger Ship": 60, // Additional name for passenger ships
    "Cargo Ship": 70, // Additional name for cargo ships
    "Container Ship": 71, // Additional name for container ships
    "Bulk Carrier": 72, // Additional name for bulk carriers
    "Reefer Ship": 73, // Additional name for reefer ships
    "General Cargo Ship": 74, // Additional name for general cargo ships
    "LNG Tanker": 75, // Additional name for LNG tankers
    "LPG Tanker": 76, // Additional name for LPG tankers
    "Chemical Tanker": 77, // Additional name for chemical tankers
    "Livestock Carrier": 78, // Additional name for livestock carriers
    "Car Carrier": 79, // Additional name for car carriers
    "Multi-purpose Ship": 81, // Additional name for multi-purpose ships
    "Offshore Supply Ship": 82, // Additional name for offshore supply ships
    "Oil Spill Response Ship": 83, // Additional name for oil spill response ships
    "Research Vessel": 84, // Additional name for research vessels
    "Fishing Vessel": 30, // Additional name for fishing vessels
    "Support Vessel": 85, // Additional name for support vessels
    "Specialized Vessel": 86, // Additional name for specialized vessels
    "Submarine": 87, // Additional name for submarines
    "Hydrographic Survey Vessel": 88, // Additional name for hydrographic survey vessels
    "Icebreaker": 89, // Additional name for icebreakers
};
