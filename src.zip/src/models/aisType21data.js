"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const AisType21DataSchema = new mongoose_1.Schema({
    type: { type: Number },
    channel: { type: String }, // Tambahkan channel
    repeat: { type: Number }, // Tambahkan repeat count
    mmsi: { type: Number },
    aidType: { type: Number },
    name: { type: String },
    positionAccuracy: { type: Boolean },
    longitude: { type: Number },
    latitude: { type: Number },
    toBow: { type: Number }, // Mengganti dimBow
    toStern: { type: Number },
    toPort: { type: Number },
    toStarboard: { type: Number },
    epfd: { type: Number },
    timestamp: { type: Number },
    offPosition: { type: Boolean }, // Mengganti offPositionIndicator
    raim: { type: Boolean }, // Mengganti raimFlag
    virtualAid: { type: Boolean }, // Mengganti virtualAidFlag
    assignedMode: { type: Boolean }, // Ditambahkan
    nameExtension: { type: String }, // Ditambahkan
    sentences: { type: [String] }, // AIS sentences
    expirationTime: { type: Date, default: () => new Date(Date.now() + 24 * 60 * 60 * 1000) }, // Default 24 jam
});
// Tambahkan indeks TTL untuk `expirationTime`
AisType21DataSchema.index({ expirationTime: 1 }, { expireAfterSeconds: 0 });
const AisType21Data = (0, mongoose_1.model)('AisType21Data', AisType21DataSchema);
exports.default = AisType21Data;
