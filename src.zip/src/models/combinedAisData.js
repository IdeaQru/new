"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const CombinedAisDataSchema = new mongoose_1.Schema({
    MMSI: { type: Number, required: true, unique: true },
    coordinates: {
        type: { type: String, enum: ['Point'], required: true },
        coordinates: { type: [Number], required: true }
    },
    ShipName: { type: String },
    ShipType: { type: Number },
    Destination: { type: String },
    Flag: { type: String },
    FlagName: { type: String },
    SpeedOverGround: { type: Number },
    CourseOverGround: { type: Number },
    Heading: { type: Number },
    Timestamp: { type: String },
    // Informasi Navigasi Tambahan
    NavigationStatus: { type: String }, // Status Navigasi
    // Draught: { type: Number }, // Kedalaman Draft
    IMONumber: { type: Number }, // IMO Number
    CallSign: { type: String }, // Tanda Panggil Kapal (Call Sign)
    // Informasi ETA
    ETA: {
        Day: { type: Number },
        Hour: { type: Number },
        Minute: { type: Number },
        Month: { type: Number },
    },
    // Dimensi Kapal
    ShipDimensions: {
        ToBow: { type: Number },
        ToStern: { type: Number },
        ToPort: { type: Number },
        ToStarboard: { type: Number },
    },
    // Kapal Terdekat
    NearestVessels: [
        {
            MMSI: { type: Number, required: true },
            ShipName: { type: String },
            Distance: { type: Number, required: true },
            RelativeBearing: { type: Number, required: true },
        },
    ],
    RawAIS: { type: String },
    ExpirationTime: { type: Date, default: () => new Date(Date.now() + 1 * 60 * 60 * 1000) }, // Waktu kadaluarsa 12 jam
    // Menambahkan AisTypeDynamic dan AisTypeStatic
    AisTypeDynamic: { type: Number }, // Tipe AIS dari data dinamis
    AisTypeStatic: { type: Number }, // Tipe AIS dari data statis
    aidtype: { type: Number }, // Tipe AIS dari data statis
    // Menambahkan deskripsi tipe AIS
    navstatDesk: { type: String },
    msgDynamicDesk: { type: String },
    msgStaticDesk: { type: String },
    vesseltypeDesk: { type: String },
});
CombinedAisDataSchema.index({ ExpirationTime: 1 }, { expireAfterSeconds: 0 }); // Menghapus dokumen setelah waktu kedaluwarsa
CombinedAisDataSchema.index({ coordinates: '2dsphere' });
const CombinedAisData = (0, mongoose_1.model)('CombinedAisData', CombinedAisDataSchema);
exports.default = CombinedAisData;
