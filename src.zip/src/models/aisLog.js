"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
// Schema for AisLog with timestamp for NearestVessels
const AisLogSchema = new mongoose_1.Schema({
    mmsi: { type: Number, required: true },
    name: { type: String, required: false },
    logTime: { type: String, required: true },
    NearestVessels: [
        {
            MMSI: { type: Number, required: true },
            ShipName: { type: String },
            Distance: { type: Number, required: true },
            RelativeBearing: { type: Number, required: true },
            coordinates: {},
            timestamp: { type: Date, default: Date.now }, // Timestamp for when the nearest vessel data is added
        },
    ],
    details: { type: mongoose_1.Schema.Types.Mixed, required: true }, // Store the detailed combined data
});
// Create a method to clean up the nearest vessels that are older than 5 minutes
AisLogSchema.methods.cleanupOldNearestVessels = function () {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000); // 5 minutes ago
    this.NearestVessels = this.NearestVessels.filter((vessel) => {
        return new Date(vessel.timestamp) > fiveMinutesAgo; // Keep only the vessels that are within the last 5 minutes
    });
};
// Before saving, cleanup the old nearest vessels and check the time constraint for details
AisLogSchema.pre('save', async function (next) {
    // Clean up the old nearest vessels before saving
    AisLogSchema.methods.cleanupOldNearestVessels(); // Clean up the old nearest vessels before saving
    // Check if the current record has the same mmsi as the last saved record
    const lastRecord = await mongoose_1.default.model('AisLog').findOne({ mmsi: this.mmsi }).sort({ logTime: -1 }).exec();
    if (lastRecord) {
        // Check if the time difference between the current log and the last saved log is less than 8 hours
        const lastSavedDate = new Date(lastRecord.logTime);
        const currentDate = new Date();
        const timeDifference = (currentDate.getTime() - lastSavedDate.getTime()) / (1000 * 60 * 60); // in hours
        if (timeDifference < 8) {
            // If less than 8 hours, prevent saving the new log and return an error message
            return next(new Error('Data must be at least 8 hours newer than the previous record.'));
        }
    }
    // Continue with the save process
    next();
});
// Create and export the model based on the schema
exports.default = mongoose_1.default.model('AisLog', AisLogSchema);
