"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShipIdentityModel = exports.DynamicModel = exports.StaticModel = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const staticDataSchema = new mongoose_1.default.Schema({
    mmsi: { type: Number, required: true },
    raw: { type: mongoose_1.default.Schema.Types.Mixed, required: true },
    data: { type: Object, required: true },
}, { timestamps: true });
exports.StaticModel = mongoose_1.default.model("StaticData", staticDataSchema);
const dynamicDataSchema = new mongoose_1.default.Schema({
    mmsi: { type: Number, required: true },
    raw: { type: String, required: true },
    data: { type: Object, required: true },
    expirationTime: { type: Date, default: () => new Date(Date.now() + 2 * 60 * 60 * 1000) },
}, { timestamps: true });
dynamicDataSchema.index({ expirationTime: 1 }, { expireAfterSeconds: 0 });
exports.DynamicModel = mongoose_1.default.model("DynamicData", dynamicDataSchema);
const shipIdentitySchema = new mongoose_1.default.Schema({
    IMO: { type: String, required: true }, // IMO sebagai string
    MMSI: { type: String, required: true }, // MMSI sebagai string
    NAME: { type: String, required: true }, // Nama kapal
    BUILT: { type: String }, // Tahun pembuatan kapal
    CALLSIGN: { type: String }, // Call sign
    FLAG: { type: String }, // Negara bendera kapal
    FLAGNAME: { type: String }, // Nama negara bendera kapal
    TYPE: { type: String }, // Tipe kapal
    TYPENAME: { type: String }, // Nama tipe kapal
    CLASS: { type: String }, // Kelas kapal
    GT: { type: String }, // Gross Tonnage kapal (kapasitas kapal)
    DWT: { type: String }, // Deadweight Tonnage kapal (beban maksimum)
    LOA: { type: String }, // Length Overall (panjang kapal)
    BEAM: { type: String }, // Lebar kapal
    DRAUGHT: { type: String }, // Kedalaman kapal
    CLASSCODE: { type: String }, // Kode klasifikasi kapal
}, {
    timestamps: true, // Menambahkan timestamps (createdAt, updatedAt)
    collection: "ship_identity", // Nama koleksi
});
// Membuat model dari schema shipIdentity
exports.ShipIdentityModel = mongoose_1.default.model('ShipIdentity', shipIdentitySchema);
