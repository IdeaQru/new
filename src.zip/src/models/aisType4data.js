"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const AisType4DataSchema = new mongoose_1.Schema({
    type: { type: Number },
    channel: { type: String }, // Tambahkan channel
    repeat: { type: Number }, // Tambahkan repeat count
    mmsi: { type: Number },
    year: { type: Number },
    month: { type: Number },
    day: { type: Number },
    hour: { type: Number },
    minute: { type: Number },
    second: { type: Number },
    accuracy: { type: Boolean },
    lon: { type: Number },
    lat: { type: Number },
    epfd: { type: Number },
    raim: { type: Boolean },
    radio: { type: Number },
    sentences: { type: [String] }, // Tambahkan sentences sebagai array string
    expirationTime: { type: Date, default: () => new Date(Date.now() + 24 * 60 * 60 * 1000) }, // Kedaluwarsa dalam 24 jam
});
// Tambahkan indeks untuk `expirationTime` agar dokumen otomatis dihapus
AisType4DataSchema.index({ expirationTime: 1 }, { expireAfterSeconds: 0 });
const AisType4Data = (0, mongoose_1.model)('AisType4Data', AisType4DataSchema);
exports.default = AisType4Data;
