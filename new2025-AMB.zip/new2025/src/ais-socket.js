"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const net = __importStar(require("net"));
const socket_io_client_1 = __importDefault(require("socket.io-client"));
class WebSocketTCPServer {
    constructor(websocketUrl, tcpPort, tcpHost = "103.24.49.138") {
        this.websocketUrl = websocketUrl;
        this.tcpPort = tcpPort;
        this.tcpHost = tcpHost;
        // Create the WebSocket connection
        this.socket = (0, socket_io_client_1.default)(this.websocketUrl, {
            transports: ["websocket"],
        });
        this.tcpServer = net.createServer((clientSocket) => {
            console.log("Local TCP client connected");
            this.socket.on("ais_mesg", (data) => {
                console.log("AIS Message Received:", data);
                const aisMessage = data.ais_mesg.trim();
                clientSocket.write(`${aisMessage}\n`);
            });
            // Handle client disconnection
            clientSocket.on("end", () => {
                console.log("Local TCP client disconnected");
            });
            // Handle client socket errors
            clientSocket.on("error", (err) => {
                console.error("Error with local TCP client:", err);
            });
        });
        // Start the TCP server
        this.tcpServer.listen(this.tcpPort, this.tcpHost, () => {
            console.log(`TCP server listening on ${this.tcpHost}:${this.tcpPort}`);
        });
        // Handle TCP server errors
        this.tcpServer.on("error", (err) => {
            console.error("Error with TCP server:", err);
        });
        this.initializeWebSocketEvents();
    }
    initializeWebSocketEvents() {
        // Event: Connection established
        this.socket.on("connect", () => {
            console.log("Connected to WebSocket server");
        });
        // Event: Disconnection
        this.socket.on("disconnect", () => {
            console.log("Disconnected from WebSocket server");
        });
        // Event: Error handling
        this.socket.on("error", (err) => {
            console.error("WebSocket Error:", err);
        });
    }
}
// Instantiate the combined WebSocket-TCP server
const websocketUrl = "http://146.190.89.97:3333"; // WebSocket server URL
const tcpPort = 5000;
const tcpHost = "127.0.0.1";
const server = new WebSocketTCPServer(websocketUrl, tcpPort, tcpHost);
