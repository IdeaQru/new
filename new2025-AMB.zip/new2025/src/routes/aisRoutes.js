"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const combinedAisData_1 = __importDefault(require("../models/combinedAisData"));
const batchProcessor_1 = require("../services/services2/batchProcessor");
const telnet_1 = require("../services/services2/telnet");
const aisDataController_1 = require("../controllers/aisDataController");
const aisLogfilterShip_1 = require("../controllers/aisLogfilterShip");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
// Inisialisasi router dan WebSocket server
const router = (0, express_1.Router)();
let latestDecodedData = null;
router.get('/get-nearest-vessel/:mmsi', aisDataController_1.getNearestVesselByMmsi);
router.get('/filter-ship-data', aisLogfilterShip_1.filterShipData);
// Rute untuk mengambil data kapal secara real-time 
router.get('/ships', async (req, res) => {
    try {
        // Safely handle query parameters (page and limit)
        const page = parseInt(req.query.page || '1'); // Default to page 1 if page is not provided
        const limit = parseInt(req.query.limit || '100'); // Default to 100 items per page
        // Calculate the number of items to skip
        const skip = (page - 1) * limit;
        const selectedFields = {
            MMSI: 1,
            coordinates: 1,
            ShipName: 1,
            Heading: 1,
            ShipType: 1,
            navstatDesk: 1,
            Destination: 1,
            SpeedOverGround: 1,
            CourseOverGround: 1,
            Timestamp: 1
        };
        // Get the total number of ships for pagination metadata
        const totalShips = await combinedAisData_1.default.countDocuments();
        // Fetch the paginated data (limit = 100 per page)
        const ships = await combinedAisData_1.default.find({})
            .select(selectedFields)
            .skip(skip)
            .limit(limit)
            .lean();
        // .maxTimeMS(1000); // Timeout query after 5 seconds
        // Send the paginated data along with metadata (e.g., total items, total pages)
        res.json({
            data: ships,
            total: totalShips,
            page: page,
            totalPages: Math.ceil(totalShips / limit), // Calculate the total number of pages
        });
    }
    catch (error) {
        console.error('Error fetching ships data:', error);
        res.status(500).send('Internal server error');
    }
});
// Rute untuk mencari kapal berdasarkan MMSI atau ShipName
router.get('/search', async (req, res) => {
    try {
        const searchQuery = req.query.search || ''; // Mengambil query pencarian
        if (!searchQuery.trim()) {
            return res.status(400).send('Search query cannot be empty');
        }
        // Tentukan apakah query adalah MMSI (angka) atau ShipName (teks)
        const searchRegex = /^[0-9]+$/.test(searchQuery) // Cek apakah query adalah angka (MMSI)
            ? { MMSI: parseInt(searchQuery) } // Pencarian berdasarkan MMSI (angka)
            : { ShipName: { $regex: new RegExp(searchQuery, 'i') } }; // Pencarian berdasarkan ShipName (string)
        const ships = await combinedAisData_1.default.find(searchRegex)
            .select({ MMSI: 1, ShipName: 1, coordinates: 1 })
            .lean();
        if (ships.length === 0) {
            return res.status(404).send('No ships found matching the search criteria');
        }
        // Kirimkan hasil pencarian
        res.json(ships);
    }
    catch (error) {
        console.error('Error searching ships:', error);
        res.status(500).send(`Internal server error: ${error.message}`);
    }
});
// Mulai pemrosesan batch secara terus menerus
(0, batchProcessor_1.startBatchProcessor)(100); // Proses batch setiap 5 detik
const HOST_AIS = process.env.AIS_HOST || '127.0.0.1';
const PORT_AIS = Number(process.env.AIS_PORT);
// Hubungkan ke server Telnet
(0, telnet_1.connectToTelnet)(HOST_AIS, PORT_AIS);
// Mulai pengiriman data melalui WebSocket setiap kali data berubah
exports.default = router;
