"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ais_stream_decoder_1 = __importDefault(require("ais-stream-decoder"));
const aisDecoder = new ais_stream_decoder_1.default();
aisDecoder.on('error', err => console.error(err));
aisDecoder.on('data', decodedMessage => console.log(decodedMessage));
const part1 = '!AIVDM,2,1,7,B,57ldlbl2Dwd1T8<W:20l923?;7R222222222221J1pC456UTN:2@U8888888,0*31';
const part2 = '!AIVDM,2,2,7,B,88888888880,2*20';
aisDecoder.write(part1);
aisDecoder.write(part2);
