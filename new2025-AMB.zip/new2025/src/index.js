"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const aisRoutes_1 = __importDefault(require("./routes/aisRoutes"));
const shapeRoutes_1 = __importDefault(require("./routes/shapeRoutes"));
const database_1 = __importDefault(require("./config/database"));
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const apiMiddleware_1 = require("./middleware/apiMiddleware");
const node_cron_1 = __importDefault(require("node-cron"));
const mailZoneRoutes_1 = __importDefault(require("./routes/mailZoneRoutes"));
const apiKeyRoutes_1 = __importDefault(require("./routes/apiKeyRoutes"));
const fs_1 = __importDefault(require("fs"));
const https_1 = __importDefault(require("https"));
const shipMovementRoutes_1 = __importDefault(require("./routes/shipMovementRoutes"));
const buoysRoutes_1 = __importDefault(require("./routes/buoysRoutes"));
const vtsRoutes_1 = __importDefault(require("./routes/vtsRoutes"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
// Inisialisasi Express
const app = (0, express_1.default)();
const HTTPS_PORT = Number(process.env.HTTPS_PORT);
// Konfigurasi CORS
const corsOptions = {
    origin: 'http://localhost:4200', // Mengizinkan hanya frontend di localhost:4200
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true, // Jika menggunakan cookie atau token
};
app.use((0, cors_1.default)(corsOptions));
app.use(express_1.default.json());
// Serve static files
app.use(express_1.default.static(path_1.default.join(__dirname, 'public')));
// Routes
app.use('/api', shipMovementRoutes_1.default);
app.use('/api', aisRoutes_1.default);
app.use('/api', shapeRoutes_1.default);
app.use('/api', authRoutes_1.default);
app.use('/api', mailZoneRoutes_1.default);
app.use('/api', apiKeyRoutes_1.default);
app.use('/api', buoysRoutes_1.default);
app.use('/api', vtsRoutes_1.default);
// Connect to database
(0, database_1.default)().catch((err) => console.error('Failed to connect to DB', err));
// Jalankan update API key pertama kali saat server start
(0, apiMiddleware_1.updateApiKey)();
// Jadwal pembaruan API key setiap 1 hari
node_cron_1.default.schedule('0 0 * * *', () => {
    (0, apiMiddleware_1.updateApiKey)();
});
// Konfigurasi sertifikat SSL
const sslOptions = {
    key: fs_1.default.readFileSync('C:/Users/user/key.pem'), // Path absolut ke private key
    cert: fs_1.default.readFileSync('C:/Users/user/cert.pem'), // Path absolut ke sertifikat
};
// Inisialisasi server HTTPS
const httpsServer = https_1.default.createServer(sslOptions, app);
// // Inisialisasi WebSocket Server dengan Socket.IO di port 3045
// const io = new SocketIOServer(Number(PORT), {
//   cors: {
//     origin: 'http://localhost:4200', // Mengizinkan hanya frontend di localhost:4200
//     methods: ['GET', 'POST'],
//     credentials: true,  // Jika ada cookie atau token yang digunakan
//   },
// });
// io.on('connection', (socket) => {
//   console.log('Client connected via WebSocket');
//   // Kirim data awal atau pesan selamat datang saat client terhubung
//   socket.emit('ais-data', 'Waiting for AIS data...');
//   let currentPage = 1;
//   const itemsPerPage = 200; // Ambil 200 data per permintaan
//   // Kirim data AIS terbaru ketika ada permintaan dari client
//   socket.on('request-data', () => {
//     // Menghitung totalItems dari CombinedAisData
//     CombinedAisData.countDocuments().then((totalItems) => {
//       const totalPages = Math.ceil(totalItems / itemsPerPage); // Total halaman berdasarkan total items
//       const metadata = {
//         currentPage,
//         itemsPerPage,
//         totalItems,
//         totalPages,
//       };
//       // Ambil data dari halaman pertama hingga halaman terakhir
//       const loadData = async () => {
//         let currentData: any[] = [];
//         for (let page = 1; page <= totalPages; page++) {
//           const data = await CombinedAisData.find()
//             .skip((page - 1) * itemsPerPage)
//             .limit(itemsPerPage)
//             .lean();
//           if (data && data.length > 0) {
//             currentData = [...currentData, ...data]; // Gabungkan data setiap halaman
//           }
//         }
//         // Emit all data when finished loading all pages
//         socket.emit('ais-data', { data: currentData, metadata });
//       };
//       loadData().catch((err) => {
//         console.error('Error loading data:', err);
//         socket.emit('ais-data', 'Error loading data');
//       });
//     }).catch(err => {
//       console.error('Error counting documents:', err);
//       socket.emit('ais-data', 'Error counting documents');
//     });
//   });
//   socket.on('disconnect', () => {
//     console.log('Client disconnected');
//   });
// });
// Angular dist path untuk serving aplikasi frontend
const angularDistPath = path_1.default.join(__dirname, '../angular-aisweb');
app.use(express_1.default.static(angularDistPath));
app.get('*', (req, res) => {
    res.sendFile(path_1.default.join(angularDistPath, 'index.html'));
});
// Menangani rute yang tidak ditemukan
app.use((req, res, next) => {
    res.status(404).send('Route not found');
});
// Jalankan server HTTPS
httpsServer.listen(HTTPS_PORT, () => {
    console.log(`HTTPS Server is running on https://localhost:${HTTPS_PORT}`);
});
exports.default = app;
