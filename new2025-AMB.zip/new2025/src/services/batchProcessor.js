"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startBatchProcessor = void 0;
const rawData_1 = require("../models/rawData");
const aisProcessor_1 = require("../services/aisProcessor");
const delay_1 = require("../utils/delay");
const ais_stream_decoder_1 = __importDefault(require("ais-stream-decoder")); // Import AisDecoder
const rawData_2 = __importDefault(require("../models/rawData"));
const parser = new ais_stream_decoder_1.default(); // Initialize the decoder
const startBatchProcessor = (interval) => __awaiter(void 0, void 0, void 0, function* () {
    while (true) {
        try {
            // Ambil raw data yang belum didecode
            const batchData = yield (0, rawData_1.getUnprocessedRawData)(100); // Ambil 100 data raw yang belum didecode
            if (batchData.length > 0) {
                let index = 0; // Set the index to loop through data one at a time
                while (index < batchData.length) {
                    const data = batchData[index]; // Get the data one at a time from the batch
                    if (data.status === false) { // Process only if the data is not decoded
                        try {
                            // Dekode raw message AIS menggunakan AisDecoder
                            parser.write(data.rawMessage); // This will trigger the 'data' event on the parser
                        }
                        catch (err) {
                            console.error('AIS Parser Error:', err);
                        }
                    }
                    index++; // Move to the next data in the batch
                }
                console.log(`Processed ${batchData.length} raw AIS messages`);
            }
            else {
                console.log('No raw AIS messages to process');
            }
        }
        catch (error) {
            console.error('Batch processing error:', error);
        }
        yield (0, delay_1.delay)(interval); // Menunggu sesuai interval sebelum mengambil batch berikutnya
    }
});
exports.startBatchProcessor = startBatchProcessor;
// Event listener for handling decoded data
parser.on('data', (decodedData) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('Decoded AIS Data:', decodedData);
        if ('type' in decodedData) {
            // Find raw data based on the rawMessage
            const rawData = yield rawData_2.default.findOne({ rawMessage: decodedData.rawMessage });
            if (rawData) {
                // Mark raw data as decoded after processing
                yield (0, rawData_1.markRawDataAsProcessed)(rawData._id);
            }
            // Send decoded data to aisProcessor for further processing
            yield (0, aisProcessor_1.processAisMessage)(decodedData);
        }
    }
    catch (err) {
        console.error('AIS Processing Error:', err);
    }
}));
// Handle errors from the parser
parser.on('error', (err) => {
    console.error('AIS Decoder Error:', err);
});
