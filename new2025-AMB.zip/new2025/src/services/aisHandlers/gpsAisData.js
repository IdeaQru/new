"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gpsAisService = void 0;
const gpsAisdata_1 = require("../../models/gpsAisdata");
class gpsAisService {
    // Fungsi untuk membuat atau memperbarui data AIS
    async saveAisData(data) {
        const existingData = await gpsAisdata_1.gpsAisData.findOne({ mmsi: data.mmsi });
        if (existingData) {
            // Update data jika sudah ada
            await gpsAisdata_1.gpsAisData.updateOne({ mmsi: data.mmsi }, data);
            console.log(`Updated AIS data for MMSI: ${data.mmsi}`);
        }
        else {
            // Simpan data baru
            const newData = new gpsAisdata_1.gpsAisData(data);
            await newData.save();
            console.log(`Saved new AIS data for MMSI: ${data.mmsi}`);
        }
    }
    // Fungsi untuk mengambil data berdasarkan MMSI
    async getAisDataByMmsi(mmsi) {
        return gpsAisdata_1.gpsAisData.findOne({ mmsi });
    }
    // Fungsi untuk mendapatkan semua data AIS
    async getAllAisData() {
        return gpsAisdata_1.gpsAisData.find();
    }
}
exports.gpsAisService = gpsAisService;
