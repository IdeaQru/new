"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNearestVesselByMmsi = exports.getLatestAisData = exports.getAisLogs = exports.processAisMessage = void 0;
const aisLog_1 = __importDefault(require("../models/aisLog"));
const processAisMessage = async (data) => {
    try {
        const aisLog = new aisLog_1.default({
            mmsi: data.mmsi,
            type: data.type,
            lat: data.lat || null,
            lon: data.lon || null,
            speed: data.speed || null,
            course: data.course || null
        });
        await aisLog.save();
        console.log('Saved AIS message to MongoDB:', aisLog);
    }
    catch (error) {
        console.error('Error processing AIS message:', error);
    }
};
exports.processAisMessage = processAisMessage;
const getAisLogs = async (req, res) => {
    try {
        const aisLogs = await aisLog_1.default.find({});
        res.json(aisLogs);
    }
    catch (error) {
        console.error('Error fetching AIS log:', error);
        res.status(500).send('Internal server error');
    }
};
exports.getAisLogs = getAisLogs;
const getLatestAisData = async (req, res) => {
    try {
        const latestData = await aisLog_1.default.findOne().sort({ timestamp: -1 });
        res.json(latestData);
    }
    catch (error) {
        console.error('Error fetching latest AIS data:', error);
        res.status(500).send('Internal server error');
    }
};
exports.getLatestAisData = getLatestAisData;
const getNearestVesselByMmsi = async (req, res) => {
    var _a;
    try {
        const { mmsi } = req.params; // Mengambil MMSI dari parameter URL
        if (!mmsi) {
            return res.status(400).json({ error: 'MMSI parameter is required' });
        }
        // Langkah 1: Temukan AisLog berdasarkan MMSI (bukan _id)
        const ship = await aisLog_1.default.findOne({ mmsi: parseInt(mmsi) });
        if (!ship) {
            return res.status(404).json({ error: `Ship with MMSI ${mmsi} not found` });
        }
        // Langkah 2: Ambil dan format NearestVessels dari data kapal
        const nearestVessels = ((_a = ship.NearestVessels) === null || _a === void 0 ? void 0 : _a.map((vessel) => ({
            MMSI: vessel.MMSI,
            ShipName: vessel.ShipName || 'Unknown Ship', // Jika ShipName kosong, tampilkan 'Unknown Ship'
            Distance: vessel.Distance,
            RelativeBearing: vessel.RelativeBearing,
            Coordinates: vessel.coordinates // Tambahkan koordinat kapal terdekat
        }))) || []; // Jika NearestVessels undefined, kembalikan array kosong
        // Kembalikan NearestVessels dalam respon
        res.status(200).json({
            MMSI: ship.mmsi,
            ShipName: ship.name || 'Unknown Ship',
            NearestVessels: nearestVessels
        });
    }
    catch (error) {
        console.error('Error fetching nearest vessels:', error);
        res.status(500).json({ message: 'Internal server error', error });
    }
};
exports.getNearestVesselByMmsi = getNearestVesselByMmsi;
