"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApiKeysbyID = exports.getApiKeys = exports.createApiKey = void 0;
const apiKeyService_1 = __importDefault(require("../services/apiKeyService"));
// Controller untuk membuat API Key
const createApiKey = async (req, res) => {
    try {
        const { userId, username, email, apiKeyCount } = req.body; // Mengambil data dari request body
        // Memanggil ApiKeyService untuk membuat API keys
        const result = await apiKeyService_1.default.createApiKeys({
            userId,
            username,
            email,
            apiKeyCount,
        });
        // Mengirimkan response dengan API keys yang berhasil dibuat
        res.status(201).json({
            message: result.message,
            generatedKeys: result.generatedKeys,
        });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error generating API keys' });
    }
};
exports.createApiKey = createApiKey;
const getApiKeys = async (req, res) => {
    try {
        const apiKeys = await apiKeyService_1.default.getApiKeys();
        res.status(200).json(apiKeys);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching API keys' });
    }
};
exports.getApiKeys = getApiKeys;
const getApiKeysbyID = async (req, res) => {
    try {
        const apiKeys = await apiKeyService_1.default.getApiKeysbyID(req.params.userId);
        res.status(200).json(apiKeys);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching API keys' });
    }
};
exports.getApiKeysbyID = getApiKeysbyID;
