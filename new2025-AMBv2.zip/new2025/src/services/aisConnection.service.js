"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startReconnectInterval = exports.connectToAisServer = void 0;
const net_1 = __importDefault(require("net"));
const rawData_1 = require("../models/rawData"); // Import fungsi untuk menyimpan raw data
const HOST = '165.154.228.42';
const AIS_PORT = 5000;
let client = null;
let buffer = '';
const connectToAisServer = () => {
    if (client) {
        client.destroy();
        console.log('Disconnected from AIS server');
    }
    client = new net_1.default.Socket();
    client.connect(AIS_PORT, HOST, () => {
        console.log(`Connected to ${HOST}:${AIS_PORT}`);
    });
    client.on('data', (data) => {
        buffer += data.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Simpan sisa data yang belum lengkap
        lines.forEach((line) => {
            // Menyimpan raw message AIS ke MongoDB
            (0, rawData_1.saveRawData)(line.trim());
        });
    });
    client.on('close', () => console.log('AIS Connection closed'));
    client.on('error', (err) => console.error(`AIS Socket Error: ${err.message}`));
};
exports.connectToAisServer = connectToAisServer;
const startReconnectInterval = () => {
    setInterval(() => {
        console.log('Reconnecting to AIS server...');
        (0, exports.connectToAisServer)();
    }, 30000);
};
exports.startReconnectInterval = startReconnectInterval;
