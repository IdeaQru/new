"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectToTelnet = connectToTelnet;
const net = __importStar(require("net"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const batchProcessor_1 = require("./batchProcessor"); // Menambahkan data ke antrean
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config(); // Menggunakan dotenv untuk mengakses variabel lingkungan
function connectToTelnet(host, port) {
    let attempt = 0; // Menghitung jumlah percobaan untuk koneksi
    // Konfigurasi pengiriman email menggunakan nodemailer
    const transporter = nodemailer_1.default.createTransport({
        host: 'mail.aisnesia.com', // Using Gmail service (can change to another provider)
        port: 465,
        secure: true,
        auth: {
            user: process.env.EMAIL_USER, // Replace with your email address
            pass: process.env.EMAIL_PASS, // Replace with your email password or app password
        }
    });
    const mailOptions = {
        from: 'info@aisnesia.com', // Ganti dengan email Anda
        to: 'info@aisnesia.com', // Ganti dengan penerima email Anda
        subject: 'Koneksi Data AIS',
        text: '', // Isi email akan diupdate setelah terhubung
    };
    const tryConnect = () => {
        const client = net.createConnection(port, host, () => {
            console.log(`Connected to ${host}:${port}`);
            attempt = 0; // Reset jumlah percobaan jika berhasil terhubung
            mailOptions.subject = 'Koneksi Data AIS Terhubung';
            // Kirim email jika berhasil terhubung kembali
            mailOptions.text = `Koneksi terhubung kembali ke ${host}:${port} pada ${new Date().toLocaleString()}. Nama PC: ${process.env.PC_NAME}`;
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Error sending email:', error);
                }
                else {
                    console.log('Email sent:', info.response);
                }
            });
        });
        client.on('data', (data) => {
            const messages = data.toString().split("\n").filter((msg) => msg.trim());
            messages.forEach((message) => (0, batchProcessor_1.addToQueue)(message.trim())); // Masukkan pesan ke antrean
        });
        client.setTimeout(30000); // 30 detik timeout
        client.on('timeout', () => {
            console.error('Telnet connection timeout. Reconnecting...');
            client.end(); // Tutup koneksi
            handleReconnect();
        });
        client.on('end', () => {
            console.log('Disconnected from server.');
            // Kirim email saat koneksi terputus
            mailOptions.subject = 'Koneksi Data AIS Terputus';
            mailOptions.text = `Koneksi terputus dari ${host}:${port} pada ${new Date().toLocaleString()}. Nama PC: ${process.env.PC_NAME}`;
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Error sending email:', error);
                }
                else {
                    console.log('Email sent:', info.response);
                }
            });
        });
        client.on('error', (err) => {
            console.error('Telnet connection error:', err);
            client.end();
            handleReconnect();
        });
        const handleReconnect = () => {
            if (attempt < 5) {
                attempt++;
                console.log(`Attempt ${attempt} of 5. Retrying...`);
                setTimeout(tryConnect, 2000); // Tunggu sebelum mencoba lagi
            }
            else {
                console.error('Max retries reached. Could not reconnect.');
            }
        };
    };
    tryConnect(); // Mulai koneksi pertama kali
}
