"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const amqplib_1 = __importDefault(require("amqplib"));
const dotenv_1 = __importDefault(require("dotenv"));
const combinedAisData_1 = __importDefault(require("../../models/combinedAisData")); // Pastikan path model sudah sesuai
// Menggunakan dotenv untuk mengakses variabel lingkungan
dotenv_1.default.config();
// Ambil URL RabbitMQ dan MongoDB dari variabel lingkungan
const RABBITMQ_URL = `amqp://${process.env.RABBITMQ_USER}:${process.env.RABBITMQ_PASSWORD}@${process.env.RABBITMQ_HOST}:${process.env.RABBITMQ_PORT}`;
// Koneksi ke RabbitMQ
async function connectRabbitMQ() {
    try {
        const connection = await amqplib_1.default.connect(RABBITMQ_URL);
        const channel = await connection.createChannel();
        return channel;
    }
    catch (err) {
        console.error('Error connecting to RabbitMQ', err);
        process.exit(1);
    }
}
// Koneksi ke MongoDB
// Kirim data ke RabbitMQ
async function sendDataToRabbitMQ(channel, data) {
    try {
        const queue = 'ships_queue'; // Nama queue RabbitMQ
        await channel.assertQueue(queue, {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' } // Pastikan tipe queue sesuai dengan yang sudah ada
        });
        // Kirim data dalam bentuk JSON string
        channel.sendToQueue(queue, Buffer.from(JSON.stringify(data)), { persistent: true });
        console.log('Data sent to RabbitMQ');
    }
    catch (err) {
        console.error('Error sending data to RabbitMQ', err);
    }
}
// Ambil data dari MongoDB dan kirim ke RabbitMQ
async function fetchAndSendData() {
    try {
        const channel = await connectRabbitMQ();
        const data = await combinedAisData_1.default.find({}).lean(); // Ambil semua data dari MongoDB
        for (const record of data) {
            await sendDataToRabbitMQ(channel, record);
        }
        channel.close();
    }
    catch (err) {
        console.error('Error fetching and sending data', err);
    }
}
// Fungsi utama untuk eksekusi
async function SendingRealtimeShips() {
    setInterval(fetchAndSendData, 5000); // Setiap 5 detik kirim data ke RabbitMQ
}
exports.default = SendingRealtimeShips;
