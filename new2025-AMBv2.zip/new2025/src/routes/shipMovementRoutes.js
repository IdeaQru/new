"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const shipMovementController_1 = require("../controllers/shipMovementController");
const router = (0, express_1.Router)();
// Endpoint untuk menambahkan pergerakan kapal
// Endpoint untuk mendapatkan semua pergerakan kapal
router.get("/ship-movements", shipMovementController_1.getShipMovements);
router.get("/ship-notifikasi", shipMovementController_1.getLatestMovement);
exports.default = router;
