"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.filterShipData = void 0;
const aisLog_1 = __importDefault(require("../models/aisLog")); // Pastikan model AisLog diimport
const turf = __importStar(require("@turf/turf"));
const moment_1 = __importDefault(require("moment"));
// Controller untuk filter ship data
const filterShipData = async (req, res) => {
    try {
        const { startDate, endDate, polygon } = req.query;
        let polygonCoords = [];
        // Parse polygon parameter menjadi array koordinat
        try {
            polygonCoords = JSON.parse(polygon);
        }
        catch (error) {
            return res.status(400).json({ error: 'Invalid polygon format' });
        }
        if (polygonCoords.length < 3) {
            return res.status(400).json({ error: 'Polygon should have at least 3 points' });
        }
        // Langkah 1: Ambil semua data log kapal
        const ships = await aisLog_1.default.find();
        // Langkah 2: Filter data berdasarkan polygon dan tanggal
        const filteredShips = ships.flatMap((ship) => {
            const filteredDetails = ship.details.filter((log) => {
                const logCoords = [log.lon, log.lat];
                // Check apakah koordinat kapal berada di dalam polygon
                const isInsidePolygon = turf.booleanPointInPolygon(turf.point(logCoords), turf.polygon([polygonCoords.map((coord) => [coord.lon, coord.lat])]));
                // Convert timestamp log menjadi objek Date untuk perbandingan
                const logDate = (0, moment_1.default)(log.timestamp, 'DD-MM-YYYY HH:mm:ss').toDate();
                const start = new Date(startDate);
                const end = new Date(endDate);
                // Filter berdasarkan rentang tanggal
                const isInDateRange = logDate >= start && logDate <= end;
                return isInsidePolygon && isInDateRange;
            });
            // Batasi hanya 5 data per hari
            const dailyLogs = [];
            const logsPerDay = new Map();
            filteredDetails.forEach((log) => {
                const date = (0, moment_1.default)(log.timestamp, 'DD-MM-YYYY HH:mm:ss').format('YYYY-MM-DD');
                if (!logsPerDay.has(date)) {
                    logsPerDay.set(date, []);
                }
                const logsForDay = logsPerDay.get(date);
                if (logsForDay && logsForDay.length < 5) {
                    logsForDay.push(log);
                    dailyLogs.push(log);
                }
            });
            // Mengembalikan data yang sudah difilter dan ditambahkan informasi nearest vessel
            return dailyLogs.map((log) => ({
                MMSI: log.MMSI,
                ShipName: log.ShipName || "Unknown Ship",
                ShipType: log.vesseltypeDesk || "Unspecified Type",
                sog: log.sog,
                cog: log.cog,
                lon: log.lon,
                lat: log.lat,
                heading: log.heading,
                destination: log.destination,
                timestamp: log.timestamp,
                navigationStatus: log.navigationStatus,
                NearestVessel: ship.NearestVessels.map((vessel) => `${vessel.ShipName} - Distance: ${vessel.Distance}`).join(", "),
            }));
        });
        // Return filtered ships in the response
        res.status(200).json(filteredShips);
    }
    catch (error) {
        console.error('Error filtering ship data:', error);
        res.status(500).json({ message: 'Internal server error', error });
    }
};
exports.filterShipData = filterShipData;
