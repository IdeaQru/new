module.exports = {
    apps: [
      {
        name: 'my-app', // Nama aplikasi kamu
        script: 'dist/server.js', // Lokasi file server setelah build
        watch: false, // Opsional: menonaktifkan watch, jika tidak ingin memantau perubahan file
        exec_mode: 'cluster', // Opsional: mode cluster untuk penggunaan multi-core
        instances: 1, // Jumlah instance (misalnya 1 atau lebih)
        autorestart: true, // Mengaktifkan restart otomatis jika aplikasi crash
        env: {
          NODE_ENV: 'production',
        },
      },
    ],
  };
  