import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './config/db';
import sensorRoutes from './routes/sensorDataRoutes';
import { consumeRabbitMQ } from './rabbitmq/consume';
import path from 'path';


dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Koneksi MongoDB
connectDB().catch((err) => console.error('Failed to connect to DB', err));


// Routes
app.use('/api', sensorRoutes);
app.use(express.static(path.join(__dirname, 'public')));
const angularDistPath = path.join(__dirname, '../myapp');
app.use(express.static(angularDistPath));
app.get('*', (req, res) => {
  res.sendFile(path.join(angularDistPath, 'index.html'));
});
// // Konsumsi RabbitMQ
consumeRabbitMQ();

// Jalankan server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
