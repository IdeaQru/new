import express from 'express';
import { getAllSensorData } from '../controllers/sensorController';

const router = express.Router();

router.get('/sensors', getAllSensorData);

export default router;
