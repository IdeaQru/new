import mongoose, { Document, Schema } from 'mongoose';

export interface ISensorData extends Document {
  sensor: string;
  value: number;
  timestamp: Date;
}

const SensorDataSchema: Schema = new Schema({
  sensor: { type: String, required: true },
  value: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
});

export default mongoose.model<ISensorData>('SensorData', SensorDataSchema);
