import amqp from 'amqplib';
import { saveSensorData } from '../controllers/sensorController';
import dotenv from 'dotenv';

dotenv.config();


// Pastikan variabel lingkungan diatur dengan benar
const RABBITMQ_HOST = process.env.RABBITMQ_HOST ;
const RABBITMQ_PORT = process.env.RABBITMQ_PORT || '5672'; // Default RabbitMQ port
const RABBITMQ_USER = process.env.RABBITMQ_USER || 'admin'; // Default username
const RABBITMQ_PASSWORD = process.env.RABBITMQ_PASSWORD || 'admin'; // Default password
const QUEUE_NAME = process.env.QUEUE_NAME || 'sensor_data';

// URL RabbitMQ untuk koneksi
const RABBITMQ_URL = `amqp://${RABBITMQ_USER}:${RABBITMQ_PASSWORD}@${RABBITMQ_HOST}:${RABBITMQ_PORT}`;

export const consumeRabbitMQ = async (): Promise<void> => {
  try {
    // Buat koneksi ke RabbitMQ
    const connection = await amqp.connect(RABBITMQ_URL);
    const channel = await connection.createChannel();

    // Pastikan queue ada
    await channel.assertQueue(QUEUE_NAME, {
        durable: true,
        arguments: {
          'x-max-length': 10485760, // Panjang maksimum
          'x-max-length-bytes': 10000, // Ukuran maksimum
          'x-queue-type': 'quorum', // Jenis queue
          'x-quorum-initial-group-size': 3, // Ukuran quorum
        },
      });
  
      
    console.log(`Listening for messages on queue: ${QUEUE_NAME}`);

    // Konsumsi pesan dari queue
    channel.consume(QUEUE_NAME, async (msg) => {
      if (msg !== null) {
        const data = JSON.parse(msg.content.toString());
        // console.log('Received:', data);

        // Simpan data ke database
        await saveSensorData(data);

        // Acknowledge pesan berhasil diproses
        channel.ack(msg);
      }
    });
  } catch (error: any) {
    console.error('Error connecting to RabbitMQ:', error.message);
  }
};
