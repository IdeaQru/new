import SensorData, { ISensorData } from '../models/sensorData';
import { Request, Response } from 'express';

// Menyimpan data ke MongoDB
export const saveSensorData = async (data: ISensorData): Promise<void> => {
  try {
    const newData = new SensorData(data);
    await newData.save();
    console.log('Data saved to MongoDB:', newData);
  } catch (error:any) {
    console.error('Error saving data to MongoDB:', error.message);
  }
};

// Mendapatkan semua data sensor dari MongoDB
export const getAllSensorData = async (req: Request, res: Response): Promise<void> => {
  try {
    const data = await SensorData.find().sort({ timestamp: -1 });
    res.status(200).json(data);
  } catch (error:any) {
    res.status(500).json({ message: 'Error fetching data', error: error.message });
  }
};
