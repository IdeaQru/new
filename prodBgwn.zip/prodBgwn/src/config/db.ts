import mongoose from 'mongoose';

const connectDB = async () => {
  const mongoURI = process.env.MONGO_URI;

  console.log('Connecting to MongoDB with URI:', mongoURI);

  if (!mongoURI) {
    console.error('MongoDB connection string is not defined in environment variables');
    process.exit(1);
  }

  try {
    // Gunakan family: 4 untuk memastikan koneksi melalui IPv4
    await mongoose.connect(mongoURI, {
      family: 4,
    });

    console.log('MongoDB connected successfully');
  } catch (error: any) {
    console.error('MongoDB connection error:', error.message);
    process.exit(1);
  }
};

export default connectDB;
